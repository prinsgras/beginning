# Quinn's 2nd Birthday Website

A beautiful photo and video gallery celebrating Quinn's 2nd birthday and his growth journey.

## Features

- **Responsive Design**: Works perfectly on all devices
- **Photo Gallery**: Beautiful lightbox gallery with all of Quinn's photos
- **Video Section**: Interactive video player for Quinn's special moments
- **Smooth Navigation**: Easy navigation between different sections
- **Birthday Animations**: Fun animations and effects throughout the site

## Sections

1. **Home**: Welcome section with birthday message
2. **Dagje Uit**: Quinn playing and growing
3. **Samen Eten**: Family moments and birthday party
4. **Spelen**: Playing with friends and family
5. **Alle Foto's**: Complete photo gallery
6. **Video's**: Video moments collection

## Technical Details

- Built with HTML5, CSS3, and JavaScript
- Uses Bootstrap 5 for responsive layout
- Lightbox2 for photo gallery functionality
- Font Awesome icons
- Google Fonts (Fredoka and Comic Neue)

## Running the Website

The website is ready to run on any web server. For local development:

```bash
python3 -m http.server 8080
```

Then open http://localhost:8080 in your browser.

## Files Structure

- `index.html` - Main website file
- `style.css` - Custom styling
- `script.js` - Interactive functionality
- `Attached_assets/` - Photos and videos
- `assets/Photos/` - Additional photos

Made with love by Papa & Mama 💕